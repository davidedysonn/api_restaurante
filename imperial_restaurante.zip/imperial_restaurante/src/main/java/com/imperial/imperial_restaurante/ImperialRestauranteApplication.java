package com.imperial.imperial_restaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImperialRestauranteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImperialRestauranteApplication.class, args);
	}

}
