package com.imperial.imperial_restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImperialRestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
